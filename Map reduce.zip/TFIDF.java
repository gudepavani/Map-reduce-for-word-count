//PGUDE, Pavani Gude, 800923558, pgude@uncc.edu


package org.myorg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

	public class TFIDF extends Configured implements Tool {
		private static final Logger LOG = Logger .getLogger( TFIDF.class);

	   public static void main( String[] args) throws  Exception {
	      int res  = ToolRunner .run( new TFIDF(), args);
	      System .exit(res);
	   }
	   
	   public static String INPUTTODOCS  = "inputtotDocs";
	   
	   public int run( String[] args) throws  Exception {
			  
		//job is the first job and chainedJob means the second one
		      Job job  = Job .getInstance(getConf(), " totDocs ");  // totdoc means total Document which will further store final output file
		      job.setJarByClass( this .getClass());
		    
		      long count =  (FileSystem.get(getConf())).getContentSummary(new Path(args[0])).getFileCount();  //gets the number of files for the calculation of IDF
		      getConf().set(INPUTTODOCS, ""+count);
		     
		      
		      FileInputFormat.setInputPaths(job,  args[0]);									//setting input and output path for the first job
		      FileOutputFormat.setOutputPath(job,  new Path(args[1]+"intermediate"));		//copying the intermediate output to a temporary location which is output path + "intermediate"
		      
		    
		      job.setMapperClass( Map .class);
		      job.setReducerClass( Reduce .class);
		      job.setOutputKeyClass( Text .class);
		      job.setOutputValueClass( IntWritable .class);
		      
		      boolean jobComplete = job.waitForCompletion( true);		//only if the first job completes
		      
		      if(jobComplete)
		      {
		    	 Job chainedJob  = Job .getInstance(getConf(), " totDocs ");
		    	 chainedJob.setJarByClass( this .getClass());

		          
		    	 chainedJob.setMapperClass( SecondMapper .class);
		    	 chainedJob.setReducerClass( SecondReducer .class);
		    	 chainedJob.setOutputKeyClass( Text .class);
		    	 chainedJob.setOutputValueClass( Text .class);
		    	 
		          FileInputFormat.addInputPath(chainedJob, new Path(args[1]+"intermediate"));  //setting input and output path for the chained job. output of first job is the input here
		          FileOutputFormat.setOutputPath(chainedJob,  new Path(args[1]));
		          
		          if(chainedJob.waitForCompletion(true)){
		        	  return 0;
		          }
		          else return 1;

		      }
		      
		      if(job.waitForCompletion(true)){
	        	  return 0;
	          }
	          else return 1;
		      	      
		      
		   }
	   
		   public static class Map extends Mapper<LongWritable ,  Text ,  Text ,  IntWritable > {
		      private final static IntWritable one  = new IntWritable(1);
		      private Text word  = new Text();

		      private static final Pattern WORD_BOUNDARY = Pattern .compile("\\s*\\b\\s*");

		      public void map( LongWritable offset,  Text lineText,  Context context)
		        throws  IOException,  InterruptedException {

		         String line  = lineText.toString();		//current line and current word
		         Text currentWord  = new Text();
		         
		         String fileName = ((FileSplit) context.getInputSplit()).getPath().getName();
		         
		         for ( String word  : WORD_BOUNDARY .split(line)) {
		            if (word.isEmpty()) {
		               continue;
		            }
		            currentWord  = new Text(word+"#####"+fileName);   //appending the fileName to the word
		            context.write(currentWord,one);
		         }
		      }
		   }

		   public static class Reduce extends Reducer<Text ,  IntWritable ,  Text ,  DoubleWritable > {
		      @Override 
		      public void reduce( Text word,  Iterable<IntWritable > counts,  Context context)
		         throws IOException,  InterruptedException {
		         int sum  = 0;
		         for ( IntWritable count  : counts) {
		            sum  += count.get();
		         }
		        
		         context.write(word,  new DoubleWritable( 1+Math.log10(sum)));  //word with WF
		      }
		   }
		   
		   public static class SecondMapper extends Mapper<LongWritable ,  Text ,  Text ,  Text > {
			     private final static IntWritable one  = new IntWritable(1);
			     private Text word  = new Text();

			     private static final Pattern WORD_BOUNDARY = Pattern .compile("\\s*\\b\\s*");

			     public void map( LongWritable offset,  Text fileNameAndTF,  Context context)
			       throws  IOException,  InterruptedException {

			        String line  = fileNameAndTF.toString();			        
			        
			        if(line.isEmpty())
			        {
			       	return;
			        }
			        
			        String[] split = line.split("#####"); //Splitting word and <filename with tab WF>
			        Text word = new Text(split[0]);
			        Text fileNameAndTf = new Text(split[1]);
			        
			        //Splitting filename and WF
			        //String[] splitFileNameAndTF = wordFNwithTF.toString().split("\t");
			        
			        Text secondSplit = new Text(fileNameAndTf);			       
			        context.write(word, secondSplit);
			        
			     }
			  }
		   
		   public static class SecondReducer extends Reducer<Text ,  Text ,  Text ,  DoubleWritable > {
			     @Override 
			     public void reduce( Text word,  Iterable<Text > fileNameAndTF,  Context context)
			        throws IOException,  InterruptedException {
			   	
			   	 
			   	ArrayList<Text> occurances = new ArrayList<Text>();
			   	double tfidf = 0.0;
			   	 
			   
			        for (Text wordValue  : fileNameAndTF) {
			           
			       	occurances.add(new Text(wordValue.toString()));  //adds all the words to the occurances
			       	 
			        }
			       
			        long totDocs = context.getConfiguration().getLong(INPUTTODOCS, 1);
			        
			        for (int i=0;i<occurances.size();i++)
			        {
			       	String filenameWithWF = occurances.get(i).toString();
			       	String[] withoutTabsFileNameAndTF = filenameWithWF.toString().split("\t");  //splitting the filename and WF
			       	double wf = Double.parseDouble(withoutTabsFileNameAndTF[1]);
			       	
			       	//IDF(t) = log​10​ (1 + Total # of documents / # of documents containing term t) 

			       	double idf = Math.log10(1+(totDocs/occurances.size())); //Calculating IDF
			       	 
			       	tfidf = wf * idf; //Calculating TFIDF
			       	 
			       	Text finalDoc  = new Text(word+"#####"+withoutTabsFileNameAndTF[0].toString());
			       	 
			        context.write(finalDoc,new DoubleWritable(tfidf));    //final output with word and tfidf
}
			     }
		   }
	}
