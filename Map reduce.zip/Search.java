//PGUDE, Pavani Gude, 800923558, pgude@uncc.edu

package org.myorg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;


public class Search extends Configured implements Tool {

   private static final Logger LOG = Logger .getLogger( Search.class);
   public static ArrayList<String> occurances = new ArrayList<String>();
   public static String INPUTWORDS = "inputwords";

   public static void main( String[] args) throws  Exception {
      int res  = ToolRunner .run( new Search(), args);
      System .exit(res);
   }

  
   public int run( String[] args) throws  Exception {	   
	   if(args.length >2){
		   for(int i=2;i<args.length;i++)			//search happens only if user enters something after javaFilename, input and output paths
		     {
		   	 occurances.add(args[i]);
		     }
		  String[] inputStrArray = new String[occurances.size()];
		  inputStrArray = occurances.toArray(inputStrArray);
		
	      Job job  = Job .getInstance(getConf(), " search ");
	      job.setJarByClass( this .getClass());
	    
	      job.getConfiguration().setStrings(INPUTWORDS,inputStrArray);

	      FileInputFormat.addInputPaths(job,  args[0]);
	      FileOutputFormat.setOutputPath(job,  new Path(args[ 1]));
	      job.setMapperClass( Map .class);
	      job.setReducerClass( Reduce .class);
	      job.setOutputKeyClass( Text .class);
	      job.setOutputValueClass( DoubleWritable .class);

	      if(job.waitForCompletion(true)){
	    	  return 0;
	      }
	      else return 1; 
	   }
	   else return -1;
	  
   }
   
   public static class Map extends Mapper<LongWritable ,  Text ,  Text ,  DoubleWritable > {
      private final static IntWritable one  = new IntWritable(1);
      private Text word  = new Text();

      private static final Pattern WORD_BOUNDARY = Pattern .compile("\\s*\\b\\s*");

      public void map( LongWritable offset,  Text lineText,  Context context)
        throws  IOException,  InterruptedException {

         String line  = lineText.toString();
         String[] split = line.split("\t");
         String tfidfStringValue = split[1].toString();
         String[] splitWordAndFilename = split[0].split("#####");
         String word = splitWordAndFilename[0].toString();
         String filename = splitWordAndFilename[1].toString();
         
         double tfidfVal = Double.parseDouble(tfidfStringValue);
         
         String[] inputList = context.getConfiguration().getStrings(INPUTWORDS);
         
         for(String w:inputList){
        	if(word.equalsIgnoreCase(w)){
        		 context.write(new Text(filename),new DoubleWritable(tfidfVal));
        	} 
         }
      }
   }

   public static class Reduce extends Reducer<Text ,  DoubleWritable ,  Text ,  DoubleWritable > {
      @Override 
      public void reduce( Text fileName,  Iterable<DoubleWritable > tfidfs,  Context context)
         throws IOException,  InterruptedException {
         
    	 
    	 double new_tfidf = 0.0;
	   	 
	   	 
	        for ( DoubleWritable tfidfValue  : tfidfs) {
	           
	       	new_tfidf = new_tfidf + tfidfValue.get();
	        }
        
         
         context.write(new Text(fileName),  new DoubleWritable(new_tfidf));
      }
   }
}